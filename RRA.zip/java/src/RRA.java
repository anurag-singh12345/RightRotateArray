public class RightRotateArray {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        int stepsToRotate = 5;
        rightRotateArray(array, stepsToRotate);

       
        for (int num : array) {
            System.out.print(num + " ");
        }
    }

    private static void rightRotateArray(int[] arr, int steps) {
        int length = arr.length;

      
        steps = steps % length;

        reverseArray(arr, 0, length - 1);
        reverseArray(arr, 0, steps - 1);
        reverseArray(arr, steps, length - 1);
    }

    private static void reverseArray(int[] arr, int start, int end) {
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;
            end--;
        }
    }
}